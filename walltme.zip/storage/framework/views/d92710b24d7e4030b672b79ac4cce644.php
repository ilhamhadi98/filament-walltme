<h3
    <?php echo e($attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH /media/ilhamhadi/data1/laravel-site/filament-walltme/vendor/filament/notifications/src/../resources/views/components/title.blade.php ENDPATH**/ ?>